package com.example.abhishek.assignment1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    public int checkPrime(int num) {
        int i,flag=0,prime=0;
        for (i = 2; i <= (num/2); i++) {
            if (num%i==0) {
                prime=11;
                flag=1;
                return prime;
            }
        }
        if (flag==0)
            prime=111;
        return prime;
    }
    private Button mTrue;
    private Button mFalse;
    private Button mNext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mTrue=(Button)findViewById(R.id.button);
        mFalse=(Button)findViewById(R.id.button2);
        mNext=(Button)findViewById(R.id.button3);

        final TextView textR=(TextView)findViewById(R.id.textView3);
        final int num=(int)(Math.random()*1000);
        textR.setText(" "+num);
        final int isprime=checkPrime(num);
        final TextView textPrime=(TextView)findViewById(R.id.textView4);

        mTrue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isprime==11){
                    textPrime.setText("You are incorrect!\n" + "Score : 0/1");
                }
                if(isprime==111) {
                    textPrime.setText("You are correct!\n" + "Score : 1/1");
                }
            }
        });

        mFalse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isprime==11){
                    textPrime.setText("You are correct!\n" + "Score : 1/1");
                }
                if(isprime==111) {
                    textPrime.setText("You are incorrect!\n" + "Score : 0/1");
                }
            }
        });

        mNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               textPrime.setText("No further questions!!");
            }
        });
    }
}
